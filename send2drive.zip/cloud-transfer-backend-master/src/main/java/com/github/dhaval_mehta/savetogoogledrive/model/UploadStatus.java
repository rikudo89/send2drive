package com.github.dhaval_mehta.savetogoogledrive.model;

public enum UploadStatus {
    waiting, uploading, failed, completed
}
